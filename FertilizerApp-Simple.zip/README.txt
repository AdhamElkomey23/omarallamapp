# نظام إدارة مصنع الأسمدة
Fertilizer Factory Management System

## طرق التشغيل / How to Run:

### الطريقة الأولى (الأسهل):
انقر مرتين على: RUN.bat
Double-click: RUN.bat

### الطريقة الثانية (صامتة):
انقر مرتين على: RUN.vbs
Double-click: RUN.vbs

### الطريقة الثالثة (مباشرة):
انقر مرتين على: FertilizerApp.html
Double-click: FertilizerApp.html

## ملاحظات / Notes:
- جميع البيانات تحفظ تلقائياً في المتصفح
- All data is automatically saved in browser
- يعمل بدون إنترنت
- Works without internet
- لا يحتاج تثبيت
- No installation required

شركة الواصلون للتعدين والصناعات الكيميائية