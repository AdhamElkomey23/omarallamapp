#!/bin/bash
clear
echo "================================================"
echo "       نظام إدارة مصنع الأسمدة"
echo "    Fertilizer Factory Management App"
echo "================================================"
echo ""
echo "جارٍ تشغيل النظام..."
echo "Starting the system..."
echo ""
node server.js